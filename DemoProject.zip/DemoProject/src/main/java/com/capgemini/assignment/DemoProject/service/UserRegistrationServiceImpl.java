package com.capgemini.assignment.DemoProject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.assignment.DemoProject.dao.UserRegistrationDao;
import com.capgemini.assignment.DemoProject.model.User;


@Service
public class UserRegistrationServiceImpl implements UserRegistrationService {

	@Autowired
	UserRegistrationDao userRegistrationDao; 
	@Override
	public boolean UserRegistration(User user) {
		
		if(userRegistrationDao.save(user) != null)
		{
			return true;
		}
		else {
			return false;
		}
	}

}
