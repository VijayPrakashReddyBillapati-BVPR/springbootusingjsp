package com.capgemini.assignment.DemoProject.dao;
import com.capgemini.assignment.DemoProject.model.User;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

@Service
public interface UserLoginDao extends JpaRepository<User ,  Integer> {
	
	@Query(value = "SELECT * FROM user u WHERE u.id =  :id")
    public User findAllActiveUsersNative(@Param("id") Integer id);
}
