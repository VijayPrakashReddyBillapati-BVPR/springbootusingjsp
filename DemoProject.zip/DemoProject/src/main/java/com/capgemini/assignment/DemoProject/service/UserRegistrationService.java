package com.capgemini.assignment.DemoProject.service;

import org.springframework.stereotype.Service;

import com.capgemini.assignment.DemoProject.model.User;


@Service
public interface UserRegistrationService {
	
	public boolean UserRegistration( User user );

}
