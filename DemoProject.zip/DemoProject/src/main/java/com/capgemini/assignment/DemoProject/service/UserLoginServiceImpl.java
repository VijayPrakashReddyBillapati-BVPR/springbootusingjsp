package com.capgemini.assignment.DemoProject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.assignment.DemoProject.dao.UserLoginDao;
import com.capgemini.assignment.DemoProject.model.User;


@Service
public class UserLoginServiceImpl  implements UserLoginService{

	@Autowired
	UserLoginDao userLoginDao;
	@Override
	public boolean Userlogin(User user) {
	User userlogin=	userLoginDao.findAllActiveUsersNative(user.getId());
	
	if(userlogin.getId()!=0)
	{
		return true;
	}
	else {
		
	return false;
	}
	
	}

}
