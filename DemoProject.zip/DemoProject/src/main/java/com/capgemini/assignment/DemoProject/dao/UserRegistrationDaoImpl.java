package com.capgemini.assignment.DemoProject.dao;

public class UserRegistrationDaoImpl {

}
