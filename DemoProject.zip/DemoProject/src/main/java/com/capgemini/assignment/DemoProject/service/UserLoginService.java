package com.capgemini.assignment.DemoProject.service;
import org.springframework.stereotype.Service;

import com.capgemini.assignment.DemoProject.model.User;

@Service
public interface UserLoginService {
	
	public boolean Userlogin( User user );

}
