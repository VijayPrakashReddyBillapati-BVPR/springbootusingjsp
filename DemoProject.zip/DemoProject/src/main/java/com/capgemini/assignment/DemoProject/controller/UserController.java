package com.capgemini.assignment.DemoProject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.assignment.DemoProject.model.User;
import com.capgemini.assignment.DemoProject.service.UserLoginService;
import com.capgemini.assignment.DemoProject.service.UserRegistrationService;

@RestController
@CrossOrigin(origins = "http://localhost:4200" , allowedHeaders = "*")
@RequestMapping("/capgemini")
public class UserController {
	
	@Autowired
	 private UserRegistrationService userRegistrationService;
	
	@Autowired
	 private UserLoginService userLoginService ;
	
	@GetMapping("/login")
	public boolean Userlogin(@RequestBody User user )
	{
		return userLoginService.Userlogin(user);
		
	}
	@PostMapping("/register")
	public boolean UserRegistration(@RequestBody User user )
	{
		return userRegistrationService.UserRegistration(user) ;
		
	}
	

}
