INSERT INTO Customer_Details(name ,email_Id ,password ,pancard_No ,address ,mobile_No , balance) VALUES
  ('vijay', 'vijay@bvpr.com', 'pass@123', 'EHBPR2079F', 'HYDERABAD', 987654321, 20122.10),
  ('prakash','prakash@bvpr.com', 'pass@456', 'EHBPR2089B', 'MUMBAI', 987654365, 10101.50),
  ('reddy', 'reddy@bvpr.com', 'pass@789', 'EHBPR3011S', 'CHENNAI', 898768721, 20118.47);